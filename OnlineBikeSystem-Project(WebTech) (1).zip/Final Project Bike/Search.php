<?php

$conn = mysql_connect("localhost", "root", "", "final_project");
$sql = "SELECT * FROM employee WHERE FirstName LIKE '%".$_POST['name']."%'";
$result = mysql_query($conn, $sql);
if(mysqli_num_rows($result)>0){
	while ($row=mysqli_fetch_assoc($result)) {
		echo " <tr>
		          <td>".$row['FirstName']."</td>
		          <td>".$row['LastName']."</td>
		          <td>".$row['Gender']."</td>
		          <td>".$row['Dob']."</td>
		          <td>".$row['Address']."</td>
		          <td>".$row['Email']."</td>
		          <td>".$row['PhoneNumber']."</td>
		          <td>".$row['Password']."</td>
		         </tr>";
	}
}
else{
	echo "<tr><td>0 result found</td></tr>";
}

?>