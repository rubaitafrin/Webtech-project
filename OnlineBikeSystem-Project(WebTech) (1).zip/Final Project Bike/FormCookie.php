<?php
$bgcolor = "#e5aeae";


if ($_SERVER['REQUEST_METHOD'] === "POST") {
	$bgcolor = $_POST['bgcolor'];
}

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Cookie</title>
</head>
<body style="background-color: <?php echo $bgcolor; ?>;">

        <form action="<?php echo $_SERVER['PHP SELF']; ?>" method="post">
        <label for="bgcolor">Select a Color:</label>
        <input type="color" name="bgcolor" id="bgcolor">
        <input type="submit" name="submit" value="Change Color">
        </form>
</body>
</html>