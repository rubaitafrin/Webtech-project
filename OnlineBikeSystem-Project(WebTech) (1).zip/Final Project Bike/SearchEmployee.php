<!DOCTYPE html>
<html lang="en">
<head>
	<title>Live Search</title>
</head>
<body>
       <h1>Live Search in Database</h1>
       <input type="text" name="Search">
       <table class="table table-hover">
       	<thead>
       		<tr>
       			<th>FirstName</th>
       			<th>LastName</th>
       			<th>Gender</th>
       			<th>Dob</th>
       			<th>Address</th>
       			<th>Email</th>
       			<th>PhoneNumber</th>
       			<th>Password</th>
       		</tr>
       	</thead>
       	<tbody id="output">
       		<tr>
       			<td>Anisur</td>
       			<td>Rahman</td>
       			<td>Male</td>
       			<td>06-10-1999</td>
       			<td>Dhaka</td>
       			<td>anisur12@gmail.com</td>
       			<td>01989727272</td>
       			<td>12123434</td>
       		</tr>
       	</tbody>
       </table>
       <script type="text/javascript">
       	   $(document).ready(function(){
       	   	  $("#search").keypress(function(){
       	   	  	$.ajax({
                  type:'POST',
                  url:'Search.php',
                  data:{
                  name:$("#Search").val(),
                  },
                  success:function(data){
                  	$("#output").html(data);
                  }
              });
       	   	  });    
       	   });
       </script>
</body>
</html>