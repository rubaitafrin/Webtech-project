
<?php

      	require_once '../model/model.php';

if (isset($_POST['updata'])) {

	$email= $_POST['email'];
	$name = $_POST['name'];
	$address = $_POST['add'];
	$phonenumber = $_POST['pn'];
	
	$pass = $_POST['password'];


  if (Update($email,$name,$address,$phonenumber,$pass)) {

  	// header( 'Location:../UserLogin.php');
  	echo 'Successfully updated!!';
  	
} else {
	echo 'You are not allowed to access this page.';
}
}


 
 ?> 


 
                    

















 
