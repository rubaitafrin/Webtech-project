<?php


session_start();

require_once '../model/db_connect.php';
$conn = db_conn();

$sql = "SELECT * FROM employee where Email= :email AND Password= :password";
$statement =$conn->prepare($sql);
$statement->execute(
array(
'email' => $_POST['email'],
'password'=> $_POST['password']
)
);

$count =$statement->rowCount();

if($count>0)
{ 
 

  $stmt = $conn->prepare("SELECT *  FROM employee ");
   $stmt->execute();


    // set the resulting array to associative
    $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);


                  
  header( 'Location:../homepage.php');
}
    
else
{
 

echo '<div class="col-lg-12 m-5 text-danger text-uppercase" style="text-align:center;"> " Incorrect Password or Email Address" </div>';
  
}

?>

<html>
<head>
  
  </head>
  <body >

 <div style="text-align:center;">   


 <a href="../views/UserLogin.php"><button  >Try Again</button></a>


 </div>
</body>

</html>
