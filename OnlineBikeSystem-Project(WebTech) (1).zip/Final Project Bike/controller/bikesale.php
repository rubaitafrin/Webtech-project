<?php $message = '';
$error = '';
require('../model/bike.php');
if(isset($_REQUEST['bikesale']))
{
if(empty($_POST["bname"]))
{
$error = "<label class='text-danger'>Bike Name Empty.</label>";
} 
else if(empty($_POST["mname"]))
{
$error = "<label class='text-danger'>Model Name Empty.</label>";
} 
else if(empty($_POST["cno"]))
{
$error = "<label class='text-danger'>Enter Chessis Number</label>";
} 
else if(empty($_POST["sdt"]))
{
$error = "<label class='text-danger'>Enter Selling Date</label>";
}
else if(empty($_POST["price"]))
{
$error = "<label class='text-danger'>Enter Price</label>";
} 
else
{
$data['BikeName']=$_POST["bname"];
    $data['ModelName']=$_POST["mname"];
      $data['ChessisNo']=$_POST["cno"];
       $data['SellingDate']=$_POST["sdt"];
    $data['Price']=$_POST["price"];

if (sale($data)) { $message = "<label class='text-danger'>Insertion Successull..!<label>"; }
else {
echo 'e1';
}
}
}
else{
echo "e2";}
?>
<?php
$err="";
$mss="";
if(isset($message))
{
echo $message;
}
?> <?php
if(isset($error))
{
 echo $error;
}
?>