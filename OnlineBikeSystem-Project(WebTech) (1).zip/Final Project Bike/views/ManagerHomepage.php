<?php include "../header/header.html";  ?>

<!DOCTYPE html>
<html>
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<title><div style="text-align:center;"> 

</div>
</title>
</head>
<body style="color: ">
    <div style="text-align:Center;">
    <br>
    <h2>Welcome JAMY</h2>
    <br><br><br>
</div>
     <fieldset>
     	<body>


            <?php
 setcookie("Cname",'Login',time()+100000,"/");
 ?>
    		
<div style="text-align:Center;">  
	<a href="../views/signup.php" class="btn btn-primary">Employee Registration</a> </br></br>

 <a href="../views/EmployeeList.php" class="btn btn-primary">Employee List</a></br></br>

 	<a href="../views/sale.php" class="btn btn-primary">Bike Sale</a> </br></br>

 <a href="../views/SellingList.php" class="btn btn-primary">Selling List</a> </br></br>

  <a href="../views/EditProfile.php" class="btn btn-primary">Edit Profile</a>

    <a href="../a.html" class="btn btn-primary">Message</a> </br></br>
</div>
 </body>

<body>
            <div id="demo">
<button  type="button" class="btn btn-outline-light text-success" onclick="loadDoc()">About Us</button>
</div>
<div class="container">
 
<script>
function loadDoc() {
  const xhttp = new XMLHttpRequest();
  xhttp.onload = function() {
    document.getElementById("demo").innerHTML = this.responseText;
  }
  xhttp.open("GET", "../views/ajax.php");
  xhttp.send();
}
</script>
     </body>
     </fieldset>
     <br><br>

</body>
    <?php include "../footer/footer.html";  ?>
</html>