<html>
<head>
<script>
function validateForm() {
  let x = document.forms["login"]["email"].value;
  if (x == "") {
    alert("Email must be filled out");
    return false;
  }
}

function validateForm1() {
  let y = document.forms["login"]["password"].value;
  if (y == "") {
    alert("Password must be filled out");
    return false;
  }
}

</script>
        <link rel="stylesheet" href="../views/style.css">
</head>
<body >


 <section>
  <div  class="contentBox">
  <div  class="formBox">
    <div style="text-align:Center;">
 <h1>Login</h1>

<form name="login" action="../controller/login.php"  method="POST" enctype="multipart/form-data" onsubmit="return validateForm(),validateForm1()">

<div class="inputBox">
  Email : <input type="text" name="email" class="form-control" placeholder="Enter your Email">
</div>
  <br>

<div class="inputBox">  
  Password: <input type="password" name="password" class="form-control"placeholder="Enter your Password"> 
</div>
<br>

<div class="inputBox">
 <input  type="submit" name="submit" value="Submit" class="btn btn-info" > 
</div>



<?php  
                     if(isset($message))  
                     {  
                          echo $message;  
                     }  
                     ?>  

                     <?php   
                     if(isset($error))  
                     {  
                          echo $error;  
                     }  
                     ?>
  

</form>



</div>
</div>
</div>
</section>
</body>
</html>

