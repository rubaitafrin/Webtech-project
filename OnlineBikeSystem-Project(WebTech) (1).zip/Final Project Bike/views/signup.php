<?php include "../header/header.html";  ?>
<!DOCTYPE html>  
 <html>  
 <head>  

           <title>Registration</title> 


       <link rel="stylesheet" href="../views/style1.css">
       
     </head>  
      <body >  
         <section>
             <div  class="contentBox">
             <div  class="formBox">
             <h1>Sign Up</h1>

                    <form name="signup" action="../controller/createUser.php" method="POST" enctype="multipart/form-data">
                   

                    <div > 
                     <?php     
                     if(isset($error))  
                     {  
                          echo $error;  
                     }  
                     ?> 
                     <br>
                    
                     <div class="inputBox">
                     <label>First Name :</label>  
                     <input type="text" name="fname" class="form-control" placeholder="Enter First Name"  />
                     </div>
                             
                     <div class="inputBox">  
                     <label>Last Name  :</label>  
                     <input type="text" name="lname" class="form-control" placeholder="Enter Last Name"/>
                     </div>
                     
                     <div class="inputBox">   
                     <label>Gender    :</label>
                     <input type="radio" id="male" name="gender" value="male" >
                     <label for="male">Male</label>                     
                     <input type="radio" id="female" name="gender" value="female">
                     <label for="female">Female</label>
                     <input type="radio" id="other" name="gender" value="other">
                     <label for="other">Other</label>
                     </div>
                   
                     <div class="inputBox">    
                     <label>Date of Birth :</label>
                     <input type="date" name="dob" > 
                 </div>
                     
                     <div class="inputBox">
                     <label>Address     :</label>
                     <input type="text" name = "add" class="form-control" placeholder="Enter your Address">
                 </div>
                    
                     <div class="inputBox">
                     <label>E-mail      :</label>
                     <input type="text" name = "email" class="form-control" placeholder="Enter your Email">
                 </div>
                     
                     <div class="inputBox">
                     <label>Phone Number :</label>
                     <input type="Number" name = "pnumber" class="form-control" placeholder="Enter your Phone number">
                 </div>
                  
                     <div class="inputBox">
                     <label>Password     :</label>
                     <input type="password" name = "np1" class="form-control" placeholder="Must be 8 digit">
                 </div>
                    
                   <div class="inputBox">
                     <input type="submit" name="createUser" value="Create Employee" ><br />  
                     </div>                    
                   
                <?php include "../footer/footer.html";  ?>

                </form>
                </div> 
                </div>  
                </form>
                </div>
                </div>
                </section> 
      </body>  
 </html>  
