<?php include "../header/header.html";  ?>
<!DOCTYPE html>
<html>
<head>
<script>
function log() {
alert("Dont Go :) ....Are You Sure you want to go !");
}
</script>



</head>
<body class="bg-warning col-lg-11.5">






<nav class="navbar navbar-expand-sm bg-success navbar-dark">



</ul>
</div>
</nav>



<table>
<tr>
<th>BikeName</th>
<th></th>
<th>ModelName</th>
<th></th>
<th>ChessisNo</th>
<th></th>
<th>SellingDate</th>
<th></th>
<th>Price</th>
</tr>





<?php



session_start();




$conn= mysqli_connect("localhost","root","","final_project");



if($conn-> connect_error){
die("Connection failed:".$conn-> connect_error);
}
$sql = "SELECT * FROM bikesale";



$result = $conn-> query($sql);



if($result-> num_rows > 0)
{
while($row = $result-> fetch_assoc() )
{




echo "<tr>
<td>" .$row["BikeName"]."</td>
<td></td>
<td>" .$row["ModelName"]."</td>
<td></td>
<td>" .$row["ChessisNo"]."</td>
<td></td>
<td>" .$row["SellingDate"]."</td>
<td></td>
<td>" .$row["Price"]."</td>
<td></td>
</tr>";






$row['Price'];
require_once '../model/model.php';




if (isset($row['Price'])) {



$Price=$row['Price'];




}


}
echo "</table>";
}
else
{
echo " 0 result";
}
$conn-> close();

?>


</table>
<br><br>
</body>
</html>
<br><br>
<br><br>
<br><br>
<br><br>

<?php include "../footer/footer.html";  ?>