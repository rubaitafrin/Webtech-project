 <?php include "../header/header.html";  ?>
 <!DOCTYPE html>  
 <html>  
      <head>  
       
  <title>Edit Profile</title> 
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
          
          <script>
function log() {
  alert("Don't go....Are You Sure you want to go !");
}

function dlt() {
  alert("Are you want to update");
}
</script> 
     </head>  
      <body class="col-lg-11.5 m-4">  
      


</ul>
</div>
</nav>


   
           <br />  
           
                <div style="text-align:center;">
                <a href="UpdateData.php" class="btn btn-success" onclick="dlt() ">Update Information</a> 
                <br><br>

              

</div>

      </body>  
 </html>  
