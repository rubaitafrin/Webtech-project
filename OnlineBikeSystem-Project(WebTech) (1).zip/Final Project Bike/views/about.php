<?php  
include "../header/header.html";
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>about</title>
</head>
<body>
	<fieldset>
		
		<legend><h3>About Online Bike Management System</h3></legend>
		<h3>What is E-commerce?</h3>
		<p>E-commerce (electronic commerce) is the activity of electronically buying or selling of products on online services or over the Internet.</p>
		<h3> What is online E-commerce platform?</h3>
		<p> An E-Commerce platform is allows online retailers to manage their business.</p>
		<h3>What is the purpose of making this management system?</h3>
		<p> With the evolution of technology and the wave of digitalization, more and more businesses are adapting to tech evolutions. The ultimate purpose behind this evolution is to make shopping a hassle-free experience for everyone. </p>
		<h4> Make life easier with "ONLINE BIKE MANAGEMENT SYSTE"</h4>

	</fieldset>

</body>
<?php include "../footer/footer.html";  ?>
</html>