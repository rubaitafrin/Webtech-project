<?php include "../header/header.html";  ?>
<!DOCTYPE html>
<html>
<head>
<script>
function log() {
alert("Dont Go :) ....Are You Sure you want to go !");
}
</script>



</head>
<body class="bg-warning col-lg-11.5">






<nav class="navbar navbar-expand-sm bg-success navbar-dark">



</ul>
</div>
</nav>



<table>
<tr>
<th>Name</th>
<th></th>
<th>Gender</th>
<th></th>
<th>Dob</th>
<th></th>
<th>Address</th>
<th></th>
<th>Email</th>
<th></th>
<th>Phone Number</th>
<th></th>
<th>Password</th>
</tr>





<?php



session_start();




$conn= mysqli_connect("localhost","root","","final_project");



if($conn-> connect_error){
die("Connection failed:".$conn-> connect_error);
}
$sql = "SELECT * FROM managerdata";



$result = $conn-> query($sql);



if($result-> num_rows > 0)
{
while($row = $result-> fetch_assoc() )
{




echo "<tr>
<td>" .$row["Name"]."</td>
<td></td>
<td>" .$row["Gender"]."</td>
<td></td>
<td>" .$row["Dob"]."</td>
<td></td>
<td>" .$row["Address"]."</td>
<td></td>
<td>" .$row["Email"]."</td>
<td></td>
<td>" .$row["PhoneNumber"]."</td>
<td></td>
<td>" .$row["Password"]."</td>

</tr>";






$row['Email'];
require_once '../model/model.php';




if (isset($row['Email'])) {



$email=$row['Email'];





}


}
echo "</table>";
}
else
{
echo " 0 result";
}
$conn-> close();

?>


</table>
<br><br>
</body>
</html>
<br><br>
<br><br>
<br><br>
<br><br>

<?php include "../footer/footer.html";  ?>