<?php
/*
if(isset($_POST["submit"]))  
 { 
 setcookie("Cname",'Login',time()+100000,"/"); 
 
 }
 else{
       echo ""; 
    }
    */   
?>





<html>
<head>
</head>
<body>
<div class="cookie_box" id="cookie_box" >
 <p>This side accept cookies</p>

 <button id ="acceptC">Accept</button>

</div>
</body>
</html>

