<?php include "header/header.html";  ?>
<!DOCTYPE html>  
 <html>  
 <head>  

           <title>Bike Sale</title> 


       
     </head>  
      <body >  

                    <form name="sale" action="controller/bikesale.php" method="POST" enctype="multipart/form-data">
                   

                    <div > 
                     <?php     
                     if(isset($error))  
                     {  
                          echo $error;  
                     }  
                     ?> 
                     <br>
                    

                     <label>Bike Name :</label>  
                     <input type="text" name="bname" class="form-control" placeholder="Enter Bike Name"  />
                     <br><br>           
                     <label>Model Name  :</label>  
                     <input type="text" name="mname" class="form-control" placeholder="Enter Model Name"/>
                     <br><br>    
                     <label>Chessis Number :</label>
                     <input type="text" name = "cno" class="form-control" placeholder="Enter your Phone number">
                     <br><br>
                     <label>Selling Date :</label>
                     <input type="date" name="sdt" > 
                     <br><br>
                     <label>Price     :</label>
                     <input type="number" name = "price" class="form-control" placeholder="Enter your Address">
                     <br><br>
                     <input type="submit" name="bikesale" value="Insert" ><br />                      
                   
                <?php include "footer/footer.html";  ?>

                </form>  
           </div>    
      </body>  
 </html>  
