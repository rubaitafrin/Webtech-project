<?php 

require_once 'db_connect.php';


function sale($data){
	$conn = db_conn();


    $sql = "INSERT INTO bikesale(BikeName,ModelName,ChessisNo,SellingDate,Price)
VALUES (:BikeName,:ModelName,:ChessisNo,:SellingDate,:Price)";
    try{
        $stmt = $conn->prepare($sql);
        $stmt->execute([




  ':BikeName' => $data['BikeName'],
   ':ModelName' => $data['ModelName'],
     ':ChessisNo' => $data['ChessisNo'],
      ':SellingDate' => $data['SellingDate'],
   ':Price' =>  $data['Price'],

        ]);
    }catch(PDOException $e){
        echo $e->getMessage();
    }
    
    $conn = null;
    return true;
}









function UpdateUser($fname,$lname,$gender,$dob,$address,$email,$p,$pass){
$conn = db_conn();

$sql = "update user SET Name=?, Address=?,PN=?,Password=? where Email= ? ";

    try{
        $stmt = $conn->prepare($sql);
        $stmt->execute([
           $name,$address ,$phonenumber, $pass , $email
        ]);
    }catch(PDOException $e){
        echo $e->getMessage();
    }
    
    $conn = null;
    return true;
}




function delete($email){
$conn = db_conn();
$sql = "delete from user where Email =?";
 try{
        $stmt = $conn->prepare($sql);
        $stmt->execute([
           $email
        ]);
    }catch(PDOException $e){
        echo $e->getMessage();
    }
    
    $conn = null;
    return true;
}