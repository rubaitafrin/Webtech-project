<?php 

require_once 'db_connect.php';


function signup($data){
	$conn = db_conn();


    $sql = "INSERT INTO employee(FirstName,LastName,Gender,Dob, Address,Email,PhoneNumber ,Password)
VALUES (:FirstName, :LastName, :Gender, :Dob, :Address,:Email,:PhoneNumber, :Password)";
    try{
        $stmt = $conn->prepare($sql);
        $stmt->execute([




  ':FirstName' => $data['FirstName'],
   ':LastName' => $data['LastName'],
     ':Gender' => $data['Gender'],
      ':Dob' => $data['Dob'],
   ':Address' =>  $data['Address'],
  ':Email' => $data['Email'],
   
    ':PhoneNumber' =>$data['PhoneNumber'],
  
  ':Password' => $data['Password'],


        ]);
    }catch(PDOException $e){
        echo $e->getMessage();
    }
    
    $conn = null;
    return true;
}









function Update($email,$name,$address,$phonenumber,$pass){
$conn = db_conn();

$sql = "UPDATE managerdata SET Name=?,Address=?,PhoneNumber=?,Password=? where Email= ? ";

    try{
        $stmt = $conn->prepare($sql);
        $stmt->execute([
           $name,$address,$phonenumber,$pass, $email
        ]);
    }catch(PDOException $e){
        echo $e->getMessage();
    }
    
    $conn = null;
    return true;
}




